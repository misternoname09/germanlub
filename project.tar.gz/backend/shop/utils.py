import os
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle
from django.conf import settings
from datetime import datetime

def generate_invoice_pdf(order):
    """
    Generates a premium PDF invoice/quote for a given order and returns the file path.
    """
    invoices_dir = os.path.join(settings.MEDIA_ROOT, 'invoices')
    os.makedirs(invoices_dir, exist_ok=True)
    
    filename = f"facture_germanlub_{order.id}.pdf"
    filepath = os.path.join(invoices_dir, filename)
    
    c = canvas.Canvas(filepath, pagesize=A4)
    width, height = A4
    
    # --- Brand Colors ---
    BRAND_COLOR = colors.HexColor('#ea580c') # Tailwind orange-600
    TEXT_COLOR = colors.HexColor('#1f2937')  # Tailwind gray-800
    LIGHT_BG = colors.HexColor('#f3f4f6')    # Tailwind gray-100
    
    # 1. HEADER
    c.setFillColor(BRAND_COLOR)
    c.rect(0, height - 15, width, 15, fill=1, stroke=0) # Top thin accent bar
    
    # Logo LES (Lubricants Engineering Solutions)
    les_logo_path = os.path.join(settings.BASE_DIR.parent, 'frontend', 'src', 'assets', 'les_logo.jpg')
    if os.path.exists(les_logo_path):
        try:
            # Placé en haut à gauche (à la place de l'ancien logo)
            c.drawImage(les_logo_path, 40, height - 100, width=80, height=80, preserveAspectRatio=True, anchor='nw')
        except Exception:
            pass
            
    # Logo GermanLub
    logo_path = os.path.join(settings.BASE_DIR.parent, 'frontend', 'src', 'assets', 'logo.jpg')
    if os.path.exists(logo_path):
        try:
            c.drawImage(logo_path, 140, height - 90, width=120, height=60, preserveAspectRatio=True, anchor='nw')
        except Exception:
            pass
    # Title
    c.setFillColor(TEXT_COLOR)
    c.setFont("Helvetica-Bold", 28)
    doc_title = "DEVIS" if getattr(order, 'is_quote', False) else "FACTURE"
    c.drawRightString(width - 40, height - 60, doc_title)
    
    # Doc Info
    c.setFont("Helvetica", 10)
    c.setFillColor(colors.gray)
    doc_label = "Devis N°" if getattr(order, 'is_quote', False) else "Facture N°"
    c.drawRightString(width - 40, height - 80, f"{doc_label} : {order.id}")
    c.drawRightString(width - 40, height - 95, f"Date : {order.created_at.strftime('%d/%m/%Y')}")
    
    # Company Info
    c.setFont("Helvetica-Bold", 10)
    c.setFillColor(TEXT_COLOR)
    c.drawString(40, height - 135, "LUBRICANTS ENGINEERING SOLUTIONS")
    c.setFont("Helvetica", 10)
    c.setFillColor(colors.gray)
    c.drawString(40, height - 150, "Dakar, Sénégal")
    c.drawString(40, height - 165, "Tél: +221 78 717 18 18 / 33 892 66 50")
    c.drawString(40, height - 180, "Email: les@les.sn")
    
    # Customer Info Box
    c.setStrokeColor(LIGHT_BG)
    c.setFillColor(LIGHT_BG)
    c.roundRect(width/2 + 20, height - 180, 240, 80, 5, fill=1, stroke=0)
    
    c.setFillColor(TEXT_COLOR)
    c.setFont("Helvetica-Bold", 10)
    billed_to_text = "Préparé pour :" if getattr(order, 'is_quote', False) else "Facturé à :"
    c.drawString(width/2 + 35, height - 120, billed_to_text)
    
    c.setFont("Helvetica-Bold", 12)
    c.drawString(width/2 + 35, height - 140, order.customer_name)
    c.setFont("Helvetica", 10)
    c.setFillColor(colors.gray)
    c.drawString(width/2 + 35, height - 155, f"Tél : {order.customer_phone}")
    c.drawString(width/2 + 35, height - 170, order.customer_address[:35] + ('...' if len(order.customer_address) > 35 else ''))
    
    # 2. ITEMS TABLE
    data = [["Description", "Qté", "Prix Unitaire", "Total"]]
    for item in order.items.all():
        product_name = item.product.name if item.product else "Produit supprimé"
        data.append([
            product_name[:45], 
            str(item.quantity), 
            f"{int(item.price):,} F CFA".replace(',', ' '), 
            f"{int(item.price * item.quantity):,} F CFA".replace(',', ' ')
        ])
        
    table = Table(data, colWidths=[240, 50, 110, 110])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), BRAND_COLOR),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('ALIGN', (1,0), (-1,-1), 'RIGHT'), # Quantities and prices right-aligned
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 10),
        ('BOTTOMPADDING', (0,0), (-1,0), 10),
        ('TOPPADDING', (0,0), (-1,0), 10),
        
        # Data rows
        ('TEXTCOLOR', (0,1), (-1,-1), TEXT_COLOR),
        ('FONTNAME', (0,1), (-1,-1), 'Helvetica'),
        ('FONTSIZE', (0,1), (-1,-1), 10),
        ('BOTTOMPADDING', (0,1), (-1,-1), 8),
        ('TOPPADDING', (0,1), (-1,-1), 8),
        ('LINEBELOW', (0,1), (-1,-1), 1, LIGHT_BG),
    ]))
    
    w, h = table.wrapOn(c, width, height)
    table.drawOn(c, 40, height - 220 - h)
    
    # 3. TOTALS
    tot_y = height - 240 - h
    c.setFont("Helvetica", 10)
    c.setFillColor(colors.gray)
    c.drawRightString(width - 150, tot_y, "Sous-total :")
    c.setFillColor(TEXT_COLOR)
    c.drawRightString(width - 40, tot_y, f"{int(order.subtotal):,} F CFA".replace(',', ' '))
    
    if order.coupon:
        tot_y -= 20
        c.setFont("Helvetica", 10)
        c.setFillColor(BRAND_COLOR)
        c.drawRightString(width - 150, tot_y, f"Réduction ({order.coupon.code}) :")
        c.drawRightString(width - 40, tot_y, f"- {int(order.discount_amount):,} F CFA".replace(',', ' '))
        
    tot_y -= 30
    c.setFillColor(LIGHT_BG)
    c.rect(width - 250, tot_y - 10, 210, 30, fill=1, stroke=0)
    
    c.setFillColor(TEXT_COLOR)
    c.setFont("Helvetica-Bold", 12)
    c.drawRightString(width - 150, tot_y, "Total TTC :")
    c.drawRightString(width - 40, tot_y, f"{int(order.total_amount):,} F CFA".replace(',', ' '))
    
    # 4. FOOTER
    c.setFillColor(colors.gray)
    c.setFont("Helvetica-Bold", 8)
    c.drawCentredString(width/2, 50, "LUBRICANTS ENGINEERING SOLUTIONS")
    c.setFont("Helvetica", 8)
    c.drawCentredString(width/2, 38, "N.I.N.E.A: 004998350 / R.C: SN.DKR.2025.A.895 / Adresse: Dakar, Sénégal")
    c.drawCentredString(width/2, 26, "Contacts: +221 78 717 18 18 / 33 892 66 50 / Website: www.les.sn / Email: les@les.sn")
    
    c.save()
    return filepath
