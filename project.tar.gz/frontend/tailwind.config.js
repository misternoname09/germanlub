/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    "./src/**/*.{html,ts}",
  ],
  theme: {
    extend: {
      colors: {
        'brand': '#e85d04', // Germanlub orange
        'brand-dark': '#dc2f02',
      }
    },
  },
  plugins: [],
}

